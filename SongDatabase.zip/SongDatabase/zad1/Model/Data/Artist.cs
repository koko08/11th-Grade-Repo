﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace zad1.Model.Data
{
    class Artist
    {
        [Key]
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Nickname { get; set; }
        [ForeignKey(nameof(Band))]
        public int BandId { get; set; }
        public Band Band { get; set; }
        public ICollection<Song> Songs { get; set; }
    }
}
