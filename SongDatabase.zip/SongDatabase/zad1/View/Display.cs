﻿using System;
using System.Collections.Generic;
using System.Text;
using zad1.Controller;
using zad1.Model;
using zad1.Model.Data;

namespace zad1.View
{
    class Display
    {
        AlbumController albumController = new AlbumController();
        private int closeOperationId = 0;
        private void ShowMainMenu()
        {
            Console.WriteLine("1. Add \n 2. Delete \n 3.Update \n 0. Exit");
        }

    }
}
