﻿using System;
using System.Collections.Generic;
using System.Text;

namespace zad1
{
    class Product
    {
        private int id;
        private string name;
        private decimal price;
        private int stock;
        private DateTime expiry;
        public int ID
        {
            set { this.id = value; }
            get { return this.id; }
        }
        public string Name
        {
            set { this.name = value; }
            get { return this.name; }
        }
        public decimal Price
        {
            set { this.price = value; }
            get { return this.price; }
        }
        public int Stock
        {
            set { this.stock = value; }
            get { return this.stock; }
        }
        public DateTime Expiry
        {
            set { this.expiry = value; }
            get { return this.expiry; }
        }
        public Product(int id, string name, decimal price, int stock, DateTime expiry)
        {
            this.ID = id;
            this.Name = name;
            this.Price = price;
            this.Stock = stock;
            this.Expiry = expiry;
        }
    }
}
