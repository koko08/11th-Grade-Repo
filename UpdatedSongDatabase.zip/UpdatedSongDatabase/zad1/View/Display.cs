﻿using System;
using System.Collections.Generic;
using System.Text;
using zad1.Controller;
using zad1.Model;
using zad1.Model.Data;

namespace zad1.View
{
    class Display
    {
        AlbumController albumController = new AlbumController();
        private int closeOperationId = 0;
        public Display()
        {
            Input();
        }
        private void ShowMainMenu()
        {
            Console.WriteLine("1. Add");
            Console.WriteLine("2. Update");
            Console.WriteLine("3. Delete");
            Console.WriteLine("4. List all data");
            Console.WriteLine("0. Exit");
        }
        private void AddMenu()
        {
            Console.WriteLine("Where do you want to add data?");
            Console.WriteLine("1. Artist");
            Console.WriteLine("2. Song");
            Console.WriteLine("3. Band");
            Console.WriteLine("4. Genre");
            Console.WriteLine("5. Subgenre");
            Console.WriteLine("0. Exit");
        }
        private void UpdateMenu()
        {
            Console.WriteLine("Which table do you want to update?");
            Console.WriteLine("1. Artist");
            Console.WriteLine("2. Song");
            Console.WriteLine("3. Band");
            Console.WriteLine("4. Genre");
            Console.WriteLine("5. Subgenre");
            Console.WriteLine("0. Exit");
        }
        private void DeleteMenu()
        {
            Console.WriteLine("Where do you want to remove data from?"); 
            Console.WriteLine("1. Artist");
            Console.WriteLine("2. Song");
            Console.WriteLine("3. Band");
            Console.WriteLine("4. Genre");
            Console.WriteLine("5. Subgenre");
            Console.WriteLine("0. Exit");
        }
        private void ListAllMenu()
        {
            Console.WriteLine("Which table do you want to see?");
            Console.WriteLine("1. Artist");
            Console.WriteLine("2. Song");
            Console.WriteLine("3. Band");
            Console.WriteLine("4. Genre");
            Console.WriteLine("5. Subgenre");
            Console.WriteLine("0. Exit");
        }
        //Better ListAll Menu
        private void Input()
        {
            int operation = -1;
            int secondOperation = -1;
            do
            {
                ShowMainMenu();
                operation = int.Parse(Console.ReadLine());
                
                switch (operation)
                {
                    case 1:
                        AddMenu();
                        secondOperation = int.Parse(Console.ReadLine());
                        switch (secondOperation)
                        {                            
                            case 1:
                                AddArtist();
                                break;
                            case 2:
                                AddSong();
                                break;
                            case 3:
                                AddBand();
                                break;
                            case 4:
                                AddGenre();
                                break;
                            case 5:
                                AddSubgenre();
                                break;
                            default:
                                break;
                        }
                        break;
                    case 2:
                        UpdateMenu();
                        secondOperation = int.Parse(Console.ReadLine());
                        switch (secondOperation)
                        {
                            case 1:
                                UpdateArtist();
                                break;
                            case 2:
                                UpdateSong();
                                break;
                            case 3:
                                UpdateBand();
                                break;
                            case 4:
                                UpdateGenre();
                                break;
                            case 5:
                                UpdateSubgenre();
                                break;
                            default:
                                break;
                        }
                        break;
                    case 3:
                        DeleteMenu();
                        secondOperation = int.Parse(Console.ReadLine());
                        switch (secondOperation)
                        {
                            case 1:
                                DeleteArtist();
                                break;
                            case 2:
                                DeleteSong();
                                break;
                            case 3:
                                DeleteBand();
                                break;
                            case 4:
                                DeleteGenre();
                                break;
                            case 5:
                                DeleteSubgenre();
                                break;
                            default:
                                break;
                        }
                        break;
                    case 4:
                        {
                            ListAllMenu();
                            secondOperation = int.Parse(Console.ReadLine());
                            switch (secondOperation)
                            {
                                case 1:
                                    ListAllArtists();
                                    break;
                                case 2:
                                    ListAllSongs();
                                    break;
                                case 3:
                                    ListAllBands();
                                    break;
                                case 4:
                                    ListAllGenre();
                                    break;
                                case 5:
                                    ListAllSubgenre();
                                    break;
                                default:
                                    break;
                            }
                        }
                        break;
                }
            } while (operation != closeOperationId);
        }
        private void AddSong()
        {
            Song song = new Song();
            Console.Write("Enter song name: ");
            song.SongName = Console.ReadLine();

            Console.Write("Enter artist id: ");
            song.ArtistId = int.Parse(Console.ReadLine());

            Console.Write("Enter song bpm: ");
            song.Bpm = int.Parse(Console.ReadLine());

            Console.Write("Enter genre id: ");
            song.GenreId = int.Parse(Console.ReadLine());

            //Finish SongLength, SongReleaseDate
            Console.Write("Enter song length: ");
            song.Length = TimeSpan.Parse(Console.ReadLine());

            Console.Write("Enter song release date: ");
            song.ReleaseDate = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter lyricist's name: ");
            song.LyricsWriter = Console.ReadLine();

            Console.Write("Enter producer's name: ");
            song.Producer = Console.ReadLine();
            albumController.AddSong(song);
        }
        private void AddArtist()
        {
            Artist artist = new Artist();
            Console.Write("Enter artist name: ");
            artist.FirstName = Console.ReadLine();

            Console.Write("Enter artist last name: ");
            artist.LastName = Console.ReadLine();

            Console.Write("Enter artist nickname: ");
            artist.Nickname = Console.ReadLine();

            Console.WriteLine("Is the artist from a band?");
            Console.WriteLine("1. Yes");
            Console.WriteLine("2. No");
            int isband = int.Parse(Console.ReadLine());
            switch (isband)
            {
                case 1:
                    Console.WriteLine("Enter band id: ");
                    artist.BandId = int.Parse(Console.ReadLine());
                    break;
                case 2:
                    break;
                default:
                    break;
            }
            albumController.AddArtist(artist);
        }
        private void AddBand()
        {
            Band band = new Band();
            Console.WriteLine("Enter band name: ");
            band.BandName = Console.ReadLine();
            albumController.AddBand(band);
        }
        private void AddSubgenre()
        {
            Subgenre subgenre = new Subgenre();
            Console.Write("Enter subgenre name: ");
            subgenre.SubgenreName = Console.ReadLine();
            albumController.AddSubgenre(subgenre);
        }
        private void AddGenre()
        {
            Genre genre = new Genre();
            Console.Write("Enter genre name: ");
            genre.GenreName = Console.ReadLine();
            Console.Write("Enter subgenre id: ");
            genre.SubgenresId = int.Parse(Console.ReadLine());
            albumController.AddGenre(genre);
        }

        private void UpdateSong()
        {
            Console.Write("Enter id to update: ");
            int id = int.Parse(Console.ReadLine());
            Song song = albumController.GetSong(id);
            if (song != null)
            {
                Console.Write("Enter song name: ");
                song.SongName = Console.ReadLine();

                Console.Write("Enter artist id: ");
                song.ArtistId = int.Parse(Console.ReadLine());

                Console.Write("Enter song bpm: ");
                song.Bpm = int.Parse(Console.ReadLine());

                Console.Write("Enter genre id: ");
                song.GenreId = int.Parse(Console.ReadLine());

                //Finish SongLength, SongReleaseDate

                Console.Write("Enter lyricist's name: ");
                song.LyricsWriter = Console.ReadLine();

                Console.Write("Enter producer's name: ");
                song.Producer = Console.ReadLine();
                albumController.UpdateSong(song);
            }
            else 
            {
                Console.WriteLine("Song not found!");
            }
        }
        private void UpdateArtist()
        {
            Console.Write("Enter id to update: ");
            int id = int.Parse(Console.ReadLine());
            Artist artist = albumController.GetArtist(id);
            if (artist != null)
            {
                Console.Write("Enter artist name: ");
                artist.FirstName = Console.ReadLine();

                Console.Write("Enter artist last name: ");
                artist.LastName = Console.ReadLine();

                Console.Write("Enter artist nickname: ");
                artist.Nickname = Console.ReadLine();

                Console.WriteLine("Is the artist from a band?");
                Console.WriteLine("1. Yes");
                Console.WriteLine("2. No");
                int isband = int.Parse(Console.ReadLine());
                switch (isband)
                {
                    case 1:
                        Console.WriteLine("Enter band id: ");
                        artist.BandId = int.Parse(Console.ReadLine());
                        break;
                    case 2:
                        break;
                    default:
                        break;
                }
                albumController.UpdateArtist(artist);
            }
            else
            {
                Console.WriteLine("Artist not found!");
            }
        }
        private void UpdateBand()
        {
            Console.Write("Enter id to update: ");
            int id = int.Parse(Console.ReadLine());
            Band band = albumController.GetBand(id);
            if (band != null)
            {
                Console.WriteLine("Enter band name: ");
                band.BandName = Console.ReadLine();
                albumController.UpdateBand(band);
            }
            else
            {
                Console.WriteLine("Band not found!");
            }
        }
        private void UpdateGenre()
        {
            Console.Write("Enter id to update: ");
            int id = int.Parse(Console.ReadLine());
            Genre genre = albumController.GetGenre(id);
            if (genre != null)
            {
                Console.Write("Enter genre name: ");
                genre.GenreName = Console.ReadLine();
                Console.Write("Enter subgenre id: ");
                genre.SubgenresId = int.Parse(Console.ReadLine());
                albumController.UpdateGenre(genre);
            }
            else
            {
                Console.WriteLine("Genre not found!");
            }
        }
        private void UpdateSubgenre()
        {
            Console.Write("Enter id to update: ");
            int id = int.Parse(Console.ReadLine());
            Subgenre subgenre = albumController.GetSubgenre(id);
            if (subgenre != null)
            {
                Console.Write("Enter subgenre name: ");
                subgenre.SubgenreName = Console.ReadLine();
                albumController.UpdateSubgenre(subgenre);
            }
            else
            {
                Console.WriteLine("Artist not found!");
            }
        }

        private void DeleteSong()
        {
            Console.Write("Enter song id to delete: ");
            int id = int.Parse(Console.ReadLine());
            albumController.DeleteSong(id);
            Console.WriteLine("Song deleted");
        }
        private void DeleteArtist()
        {
            Console.Write("Enter artist id to delete: ");
            int id = int.Parse(Console.ReadLine());
            albumController.DeleteArtist(id);
            Console.WriteLine("Artist deleted");
        }
        private void DeleteBand()
        {
            Console.Write("Enter band id to delete: ");
            int id = int.Parse(Console.ReadLine());
            albumController.DeleteBand(id);
            Console.WriteLine("Band deleted");
        }
        private void DeleteGenre()
        {
            Console.Write("Enter genre id to delete: ");
            int id = int.Parse(Console.ReadLine());
            albumController.DeleteGenre(id);
            Console.WriteLine("Genre deleted");
        }
        private void DeleteSubgenre()
        {
            Console.Write("Enter subgenre id to delete: ");
            int id = int.Parse(Console.ReadLine());
            albumController.DeleteSubgenre(id);
            Console.WriteLine("Subgenre deleted");
        }

        private void ListAllSongs()
        {
            var song = albumController.GetAllSongs();
            foreach (var item in song)
            {
                Console.WriteLine("{0,-" + 2 + "} {1,-" + 20 + "} {2,-" + 5 + "} {3,-" + 5 + "} {4,-" + 5 + "} {5,-" + 8 + "} {6,-" + 12 + "} {7,-" + 30 + "} {7,-" + 30 + "}",
                    "Id","SongName", "ArtistId", "Bpm", "GenreId", "Length", "ReleaseDate", "LyricsWriter", "Producer");
                Console.WriteLine("{0,-" + 2 + "} {1,-" + 20 + "} {2,-" + 5 + "} {3,-" + 5 + "} {4,-" + 5 + "} {5,-" + 8 + "} {6,-" + 12 + "} {7,-" + 30 + "} {7,-" + 30 + "}", 
                    item.Id, item.SongName, item.ArtistId, item.Bpm, item.GenreId, item.Length, item.ReleaseDate, item.LyricsWriter, item.Producer);
            }
        }
        private void ListAllArtists()
        {
            var artists = albumController.GetAllArtists();
            foreach (var item in artists)
            {
                Console.WriteLine("{0,-" + 2 + "} {1,-" + 20 + "} {2,-" + 20 + "} {3,-" + 20 + "} {4,-" + 5 + "}", 
                    "Id", "FirstName", "LastName", "Nickname", "BandId");
                Console.WriteLine("{0,-" + 2 + "} {1,-" + 20 + "} {2,-" + 20 + "} {3,-" + 20 + "} {4,-" + 5 + "}",
                    item.Id, item.FirstName, item.LastName, item.Nickname, item.BandId);
            }
        }
        private void ListAllBands()
        {
            var bands = albumController.GetAllBands();
            foreach (var item in bands)
            {
                Console.WriteLine("{0,-" + 2 + "} {1,-" + 15 + "}", "Id", "BandName");
                Console.WriteLine("{0,-" + 2 + "} {1,-" + 15 + "}", item.Id, item.BandName);
            }
        }
        private void ListAllGenre()
        {
            var genre = albumController.GetAllGenres();
            foreach (var item in genre)
            {
                Console.WriteLine("{0,-" + 2 + "} {1,-" + 15 + "} {2,-" + 4 + "}", "Id", "GenreName", "SubgenresId");
                Console.WriteLine("{0,-" + 2 + "} {1,-" + 15 + "} {2,-" + 4 + "}", item.Id, item.GenreName, item.SubgenresId);
            }
        }
        private void ListAllSubgenre()
        {
            var subgenre = albumController.GetAllSubgenres();
            foreach (var item in subgenre)
            {
                Console.WriteLine("{0,-" + 2 + "} {1,-" + 15 + "}", "Id", "SubgenreName");
                Console.WriteLine("{0,-" + 2 + "} {1,-" + 15 + "}", item.Id, item.SubgenreName);
            }
        }
    }
}
