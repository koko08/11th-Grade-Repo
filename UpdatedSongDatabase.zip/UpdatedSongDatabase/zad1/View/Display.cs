﻿using System;
using System.Collections.Generic;
using System.Text;
using zad1.Controller;
using zad1.Model;
using zad1.Model.Data;

namespace zad1.View
{
    class Display
    {
        AlbumController albumController = new AlbumController();
        private int closeOperationId = 0;
        public Display()
        {
            Input();
        }
        private void ShowMainMenu()
        {
            Console.WriteLine("1. Add");
            Console.WriteLine("2. Update");
            Console.WriteLine("3. Delete");
            Console.WriteLine("0. Exit");
        }
        private void AddMenu()
        {
            Console.WriteLine("1. AddArtist");
            Console.WriteLine("2. AddSong");
        }
        private void Input()
        {
            int operation = -1;
            int addOperation = -1;
            do
            {
                ShowMainMenu();
                operation = int.Parse(Console.ReadLine());
                
                switch (operation)
                {
                    case 1:
                        AddMenu();
                        addOperation = int.Parse(Console.ReadLine());
                        switch (addOperation)
                        {                            
                            case 1:
                                AddArtist();
                                break;
                            case 2:
                                AddSong();
                                break;
                            default:
                                break;
                        }
                        break;
                    case 2:
                        Delete();
                        break;
                }
            } while (operation != closeOperationId);
        }
        private void AddSong()
        {
            Song song = new Song();
            Console.Write("Enter song name: ");
            song.SongName = Console.ReadLine();

            Console.Write("Enter artist id: ");
            song.ArtistId = int.Parse(Console.ReadLine());

            Console.Write("Enter song bpm: ");
            song.Bpm = int.Parse(Console.ReadLine());

            Console.Write("Enter genre id: ");
            song.GenreId = int.Parse(Console.ReadLine());

            //Finish SongLength, SongReleaseDate

            Console.Write("Enter lyricist's name: ");
            song.LyricsWriter = Console.ReadLine();

            Console.Write("Enter producer's name: ");
            song.Producer = Console.ReadLine();
        }
        private void AddArtist()
        {
            Console.WriteLine("AddArtist");
        }
        private void Delete()
        {
            Console.WriteLine("Delete");
        }
    }
}
