﻿using System;
using System.Collections.Generic;
using System.Text;
using zad1.Controller;
using zad1.Model;
using zad1.Model.Data;

namespace zad1.View
{
    class Display
    {
        AlbumController albumController = new AlbumController();
        private int closeOperationId = 0;
        public Display()
        {
            Input();
        }
        private void ShowMainMenu()
        {
            Console.WriteLine("1. Add");
            Console.WriteLine("2. Update");
            Console.WriteLine("3. Delete");
            Console.WriteLine("0. Exit");
        }
        private void AddMenu()
        {
            Console.WriteLine("1. Add Artist");
            Console.WriteLine("2. Add Song");
            Console.WriteLine("3. Add Band");
            Console.WriteLine("4. Add Genre");
            Console.WriteLine("5. Add Subgenre");
            Console.WriteLine("0. Exit");
        }
        private void UpdateMenu()
        {
            Console.WriteLine("1. Update Artist");
            Console.WriteLine("2. Update Song");
            Console.WriteLine("3. Update Band");
            Console.WriteLine("4. Update Genre");
            Console.WriteLine("5. Update Subgenre");
            Console.WriteLine("0. Exit");
        }
        private void DeleteMenu()
        {
            Console.WriteLine("1. Delete Artist");
            Console.WriteLine("2. Delete Song");
            Console.WriteLine("3. Delete Band");
            Console.WriteLine("4. Delete Genre");
            Console.WriteLine("5. Delete Subgenre");
            Console.WriteLine("0. Exit");
        }
        //Better ListAll Menu
        private void Input()
        {
            int operation = -1;
            int secondOperation = -1;
            do
            {
                ShowMainMenu();
                operation = int.Parse(Console.ReadLine());
                
                switch (operation)
                {
                    case 1:
                        AddMenu();
                        secondOperation = int.Parse(Console.ReadLine());
                        switch (secondOperation)
                        {                            
                            case 1:
                                AddArtist();
                                break;
                            case 2:
                                AddSong();
                                break;
                            case 3:
                                AddBand();
                                break;
                            case 4:
                                AddGenre();
                                break;
                            case 5:
                                AddSubgenre();
                                break;
                            default:
                                break;
                        }
                        break;
                    case 2:
                        UpdateMenu();
                        secondOperation = int.Parse(Console.ReadLine());
                        switch (secondOperation)
                        {
                            case 1:
                                UpdateArtist();
                                break;
                            case 2:
                                UpdateSong();
                                break;
                            case 3:
                                UpdateBand();
                                break;
                            case 4:
                                UpdateGenre();
                                break;
                            case 5:
                                UpdateSubgenre();
                                break;
                            default:
                                break;
                        }
                        break;
                    case 3:
                        DeleteMenu();
                        secondOperation = int.Parse(Console.ReadLine());
                        switch (secondOperation)
                        {
                            case 1:
                                DeleteArtist();
                                break;
                            case 2:
                                DeleteSong();
                                break;
                            case 3:
                                DeleteBand();
                                break;
                            case 4:
                                DeleteGenre();
                                break;
                            case 5:
                                DeleteSubgenre();
                                break;
                            default:
                                break;
                        }
                        break;
                }
            } while (operation != closeOperationId);
        }
        private void AddSong()
        {
            Song song = new Song();
            Console.Write("Enter song name: ");
            song.SongName = Console.ReadLine();

            Console.Write("Enter artist id: ");
            song.ArtistId = int.Parse(Console.ReadLine());

            Console.Write("Enter song bpm: ");
            song.Bpm = int.Parse(Console.ReadLine());

            Console.Write("Enter genre id: ");
            song.GenreId = int.Parse(Console.ReadLine());

            //Finish SongLength, SongReleaseDate

            Console.Write("Enter lyricist's name: ");
            song.LyricsWriter = Console.ReadLine();

            Console.Write("Enter producer's name: ");
            song.Producer = Console.ReadLine();
            albumController.AddSong(song);
        }
        private void AddArtist()
        {
            Artist artist = new Artist();
            Console.Write("Enter artist name: ");
            artist.FirstName = Console.ReadLine();

            Console.Write("Enter artist last name: ");
            artist.LastName = Console.ReadLine();

            Console.Write("Enter artist nickname: ");
            artist.Nickname = Console.ReadLine();

            Console.WriteLine("Is the artist from a band?");
            Console.WriteLine("1. Yes");
            Console.WriteLine("2. No");
            int isband = int.Parse(Console.ReadLine());
            switch (isband)
            {
                case 1:
                    Console.WriteLine("Enter band id: ");
                    artist.BandId = int.Parse(Console.ReadLine());
                    break;
                case 2:
                    break;
                default:
                    break;
            }
            albumController.AddArtist(artist);
        }
        private void AddBand()
        {
            Band band = new Band();
            Console.WriteLine("Enter band name: ");
            band.BandName = Console.ReadLine();
            albumController.AddBand(band);
        }
        private void AddSubgenre()
        {
            Subgenre subgenre = new Subgenre();
            Console.Write("Enter subgenre name: ");
            subgenre.SubgenreName = Console.ReadLine();
            albumController.AddSubgenre(subgenre);
        }
        private void AddGenre()
        {
            Genre genre = new Genre();
            Console.Write("Enter genre name: ");
            genre.GenreName = Console.ReadLine();
            Console.Write("Enter subgenre id: ");
            genre.SubgenresId = int.Parse(Console.ReadLine());
            albumController.AddGenre(genre);
        }

        private void UpdateSong()
        {
            Console.Write("Enter id to update: ");
            int id = int.Parse(Console.ReadLine());
            Song song = albumController.GetSong(id);
            if (song != null)
            {
                Console.Write("Enter song name: ");
                song.SongName = Console.ReadLine();

                Console.Write("Enter artist id: ");
                song.ArtistId = int.Parse(Console.ReadLine());

                Console.Write("Enter song bpm: ");
                song.Bpm = int.Parse(Console.ReadLine());

                Console.Write("Enter genre id: ");
                song.GenreId = int.Parse(Console.ReadLine());

                //Finish SongLength, SongReleaseDate

                Console.Write("Enter lyricist's name: ");
                song.LyricsWriter = Console.ReadLine();

                Console.Write("Enter producer's name: ");
                song.Producer = Console.ReadLine();
                albumController.UpdateSong(song);
            }
            else 
            {
                Console.WriteLine("Song not found!");
            }
        }
        private void UpdateArtist()
        {
            Console.Write("Enter id to update: ");
            int id = int.Parse(Console.ReadLine());
            Artist artist = albumController.GetArtist(id);
            if (artist != null)
            {
                Console.Write("Enter artist name: ");
                artist.FirstName = Console.ReadLine();

                Console.Write("Enter artist last name: ");
                artist.LastName = Console.ReadLine();

                Console.Write("Enter artist nickname: ");
                artist.Nickname = Console.ReadLine();

                Console.WriteLine("Is the artist from a band?");
                Console.WriteLine("1. Yes");
                Console.WriteLine("2. No");
                int isband = int.Parse(Console.ReadLine());
                switch (isband)
                {
                    case 1:
                        Console.WriteLine("Enter band id: ");
                        artist.BandId = int.Parse(Console.ReadLine());
                        break;
                    case 2:
                        break;
                    default:
                        break;
                }
                albumController.UpdateArtist(artist);
            }
            else
            {
                Console.WriteLine("Artist not found!");
            }
        }
        private void UpdateBand()
        {
            Console.Write("Enter id to update: ");
            int id = int.Parse(Console.ReadLine());
            Band band = albumController.GetBand(id);
            if (band != null)
            {
                Console.WriteLine("Enter band name: ");
                band.BandName = Console.ReadLine();
                albumController.UpdateBand(band);
            }
            else
            {
                Console.WriteLine("Band not found!");
            }
        }
        private void UpdateGenre()
        {
            Console.Write("Enter id to update: ");
            int id = int.Parse(Console.ReadLine());
            Genre genre = albumController.GetGenre(id);
            if (genre != null)
            {
                Console.Write("Enter genre name: ");
                genre.GenreName = Console.ReadLine();
                Console.Write("Enter subgenre id: ");
                genre.SubgenresId = int.Parse(Console.ReadLine());
                albumController.UpdateGenre(genre);
            }
            else
            {
                Console.WriteLine("Genre not found!");
            }
        }
        private void UpdateSubgenre()
        {
            Console.Write("Enter id to update: ");
            int id = int.Parse(Console.ReadLine());
            Subgenre subgenre = albumController.GetSubgenre(id);
            if (subgenre != null)
            {
                Console.Write("Enter subgenre name: ");
                subgenre.SubgenreName = Console.ReadLine();
                albumController.UpdateSubgenre(subgenre);
            }
            else
            {
                Console.WriteLine("Artist not found!");
            }
        }

        private void DeleteSong()
        {
            Console.Write("Enter song id to delete: ");
            int id = int.Parse(Console.ReadLine());
            albumController.DeleteSong(id);
            Console.WriteLine("Song deleted");
        }
        private void DeleteArtist()
        {
            Console.Write("Enter artist id to delete: ");
            int id = int.Parse(Console.ReadLine());
            albumController.DeleteArtist(id);
            Console.WriteLine("Artist deleted");
        }
        private void DeleteBand()
        {
            Console.Write("Enter band id to delete: ");
            int id = int.Parse(Console.ReadLine());
            albumController.DeleteBand(id);
            Console.WriteLine("Band deleted");
        }
        private void DeleteGenre()
        {
            Console.Write("Enter genre id to delete: ");
            int id = int.Parse(Console.ReadLine());
            albumController.DeleteGenre(id);
            Console.WriteLine("Genre deleted");
        }
        private void DeleteSubgenre()
        {
            Console.Write("Enter subgenre id to delete: ");
            int id = int.Parse(Console.ReadLine());
            albumController.DeleteSubgenre(id);
            Console.WriteLine("Subgenre deleted");
        }

        private void ListAllSongs()
        {
            var song = albumController.GetAllSongs();
            foreach (var item in song)
            {
                //Console.WriteLine("\n Name: {0} \n Artist: {1} \n Genre: {2} \n Lyrics: {3} \n Producer: {4}", item.SongName, item.Artist, item.Genre, item.LyricsWriter, item.Producer);
            }
        }
        private void ListAllArtists()
        {
            var artists = albumController.GetAllArtists();
            foreach (var item in artists)
            {
                //Console.WriteLine("\n Name: {0} \n Artist: {1} \n Genre: {2} \n Lyrics: {3} \n Producer: {4}", item.SongName, item.Artist, item.Genre, item.LyricsWriter, item.Producer);
            }
        }
        private void ListAllBands()
        {
            var band = albumController.GetAllBands();
            foreach (var item in band)
            {
                //Console.WriteLine("\n Name: {0} \n Artist: {1} \n Genre: {2} \n Lyrics: {3} \n Producer: {4}", item.SongName, item.Artist, item.Genre, item.LyricsWriter, item.Producer);
            }
        }
        private void ListAllGenre()
        {
            var genre = albumController.GetAllGenres();
            foreach (var item in genre)
            {
                //Console.WriteLine("\n Name: {0} \n Artist: {1} \n Genre: {2} \n Lyrics: {3} \n Producer: {4}", item.SongName, item.Artist, item.Genre, item.LyricsWriter, item.Producer);
            }
        }
        private void ListAllSubgenre()
        {
            var subgenre = albumController.GetAllSubgenres();
            foreach (var item in subgenre)
            {
                //Console.WriteLine("\n Name: {0} \n Artist: {1} \n Genre: {2} \n Lyrics: {3} \n Producer: {4}", item.SongName, item.Artist, item.Genre, item.LyricsWriter, item.Producer);
            }
        }
    }
}
