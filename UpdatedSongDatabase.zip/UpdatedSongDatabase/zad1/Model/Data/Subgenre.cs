﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace zad1.Model.Data
{
    class Subgenre
    {
        [Key]
        public int Id { get; set; }
        public string SubgenreName { get; set; }
        public Genre Genre { get; set; }
    }
}
