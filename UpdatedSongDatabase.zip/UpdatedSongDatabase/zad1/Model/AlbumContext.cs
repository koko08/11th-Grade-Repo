﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using zad1.Model.Data;

namespace zad1.Model
{
    class AlbumContext : DbContext
    {
        public AlbumContext()
        {
            Database.EnsureCreated();
        }
        public DbSet<Artist> Artists { get; set; }
        public DbSet<Band> Bands { get; set; }
        public DbSet<Genre> Genres { get; set; }
        public DbSet<Subgenre> Subgenres { get; set; }
        public DbSet<Song> Songs { get; set; }
        
        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            var connString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Album;Integrated Security=true;";
            optionBuilder.UseSqlServer(connString);
        }
    }
}
