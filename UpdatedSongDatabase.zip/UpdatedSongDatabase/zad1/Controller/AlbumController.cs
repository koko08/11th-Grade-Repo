﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using zad1.Model;
using zad1.Model.Data;

namespace zad1.Controller
{
    class AlbumController
    {
        private AlbumContext albumContext;
        //GetAll
        public List<Song> GetAllSongs()
        {
            using (albumContext = new AlbumContext())
            {
                return albumContext.Songs.ToList();
            }
        }
        public List<Artist> GetAllArtists()
        {
            using (albumContext = new AlbumContext())
            {
                return albumContext.Artists.ToList();
            }
        }
        public List<Band> GetAllBands()
        {
            using (albumContext = new AlbumContext())
            {
                return albumContext.Bands.ToList();
            }
        }
        public List<Subgenre> GetAllSubgenres()
        {
            using (albumContext = new AlbumContext())
            {
                return albumContext.Subgenres.ToList();
            }
        }
        public List<Genre> GetAllGenres()
        {
            using (albumContext = new AlbumContext())
            {
                return albumContext.Genres.ToList();
            }
        }

        //Get
        public Song GetSong(int id)
        {
            using (albumContext = new AlbumContext())
            {
                return albumContext.Songs.Find(id);
            }
        }
        public Artist GetArtist(int id)
        {
            using (albumContext = new AlbumContext())
            {
                return albumContext.Artists.Find(id);
            }
        }
        public Band GetBand(int id)
        {
            using (albumContext = new AlbumContext())
            {
                return albumContext.Bands.Find(id);
            }
        }
        public Subgenre GetSubgenre(int id)
        {
            using (albumContext = new AlbumContext())
            {
                return albumContext.Subgenres.Find(id);
            }
        }
        public Genre GetGenre(int id)
        {
            using (albumContext = new AlbumContext())
            {
                return albumContext.Genres.Find(id);
            }
        }

        //Add
        public void AddSong(Song song)
        {
            using (albumContext = new AlbumContext())
            {
                albumContext.Songs.Add(song);
                albumContext.SaveChanges();
            }
        }
        public void AddArtist(Artist artist)
        {
            using (albumContext = new AlbumContext())
            {
                albumContext.Artists.Add(artist);
                albumContext.SaveChanges();
            }
        }
        public void AddBand(Band band)
        {
            using (albumContext = new AlbumContext())
            {
                albumContext.Bands.Add(band);
                albumContext.SaveChanges();
            }
        }
        public void AddSubgenre(Subgenre subgenre)
        {
            using (albumContext = new AlbumContext())
            {
                albumContext.Subgenres.Add(subgenre);
                albumContext.SaveChanges();
            }
        }
        public void AddGenre(Genre genre)
        {
            using (albumContext = new AlbumContext())
            {
                albumContext.Genres.Add(genre);
                albumContext.SaveChanges();
            }
        }

        //Delete
        public void DeleteSong(int id)
        {
            using (albumContext = new AlbumContext())
            {
                var song = albumContext.Songs.Find(id);
                if (song != null)
                {
                    albumContext.Songs.Remove(song);
                    albumContext.SaveChanges();
                }
            }
        }
        public void DeleteArtist(int id)
        {
            using (albumContext = new AlbumContext())
            {
                var artist = albumContext.Artists.Find(id);
                if (artist != null)
                {
                    albumContext.Artists.Remove(artist);
                    albumContext.SaveChanges();
                }
            }
        }
        public void DeleteBand(int id)
        {
            using (albumContext = new AlbumContext())
            {
                var band = albumContext.Bands.Find(id);
                if (band != null)
                {
                    albumContext.Bands.Remove(band);
                    albumContext.SaveChanges();
                }
            }
        }
        public void DeleteSubgenre(int id)
        {
            using (albumContext = new AlbumContext())
            {
                var subgenre = albumContext.Subgenres.Find(id);
                if (subgenre != null)
                {
                    albumContext.Subgenres.Remove(subgenre);
                    albumContext.SaveChanges();
                }
            }
        }
        public void DeleteGenre(int id)
        {
            using (albumContext = new AlbumContext())
            {
                var genre = albumContext.Genres.Find(id);
                if (genre != null)
                {
                    albumContext.Genres.Remove(genre);
                    albumContext.SaveChanges();
                }
            }
        }

        //Update
        public void UpdateSong(Song song)
        {
            using (albumContext = new AlbumContext())
            {
                var item = albumContext.Songs.Find(song);
                if (item != null)
                {
                    albumContext.Entry(item).CurrentValues.SetValues(song);
                    albumContext.SaveChanges();
                }
            }
        }
        public void UpdateArtist(Artist artist)
        {
            using (albumContext = new AlbumContext())
            {
                var item = albumContext.Artists.Find(artist);
                if (item != null)
                {
                    albumContext.Entry(item).CurrentValues.SetValues(artist);
                    albumContext.SaveChanges();
                }
            }
        }
        public void UpdateBand(Band band)
        {
            using (albumContext = new AlbumContext())
            {
                var item = albumContext.Bands.Find(band);
                if (item != null)
                {
                    albumContext.Entry(item).CurrentValues.SetValues(band);
                    albumContext.SaveChanges();
                }
            }
        }
        public void UpdateSubgenre(Subgenre subgenre)
        {
            using (albumContext = new AlbumContext())
            {
                var item = albumContext.Subgenres.Find(subgenre);
                if (item != null)
                {
                    albumContext.Entry(item).CurrentValues.SetValues(subgenre);
                    albumContext.SaveChanges();
                }
            }
        }
        public void UpdateGenre(Genre genre)
        {
            using (albumContext = new AlbumContext())
            {
                var item = albumContext.Genres.Find(genre);
                if (item != null)
                {
                    albumContext.Entry(item).CurrentValues.SetValues(genre);
                    albumContext.SaveChanges();
                }
            }
        }
    }
}
