﻿using System;
using System.Collections.Generic;
using System.Text;
using zad1.Model;
using zad1.Model.Data;

namespace zad1.Controller
{
    class AlbumController
    {
        private AlbumContext albumContext;
        public Song GetSong(int id)
        {
            using (albumContext = new AlbumContext())
            {
                return albumContext.Songs.Find(id);
            }
        }
        public void AddSong(Song song)
        {
            using (albumContext = new AlbumContext())
            {
                albumContext.Songs.Add(song);
                albumContext.SaveChanges();
            }
        }
        public void DeleteSong(int id)
        {
            using (albumContext = new AlbumContext())
            {
                var song = albumContext.Songs.Find(id);
                if (song != null)
                {
                    albumContext.Songs.Remove(song);
                    albumContext.SaveChanges();
                }
            }
        }
        public void UpdateSong(Song song)
        {
            using (albumContext = new AlbumContext())
            {
                var item = albumContext.Songs.Find(song);
                if (item != null)
                {
                    albumContext.Entry(item).CurrentValues.SetValues(song);
                    albumContext.SaveChanges();
                }
            }
        }
    }
}
