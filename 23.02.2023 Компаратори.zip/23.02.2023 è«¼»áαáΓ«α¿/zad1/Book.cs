﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad1
{
    public class Book : IComparable<Book>
    {
        public string Title { get; set; }
        public int Year { get; set; }
        public List<string> Authors { get; set; }
        public Book(string title, int year, params string[] author)//конструктор
        {
            Title = title;
            Year = year;
            Authors = new List<string>(author);
        }

        public int CompareTo(Book other)
        {
            var compare = this.Year.CompareTo(other.Year);
            if (compare == 0)
            {
                compare = this.Title.CompareTo(other.Title);
            }
            return compare;
        }
        public override string ToString()
        {
            return $"{Title} {Year}";
        }
    }
}