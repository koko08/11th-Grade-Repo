﻿using System;
using System.Threading;

namespace zad1
{
    class Program
    {
        static void Run()
        {
            int input;
            try
            {
                for (int i = 1; i <= 5; i++)
                {
                    Console.Write("First thread: ");
                    input = int.Parse(Console.ReadLine());
                    Thread.Sleep(2000);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetType().Name);
                Console.WriteLine(e.Message);
                Console.WriteLine(e.Source);
            }
        }
        static void Main(string[] args)
        {
            int input;
            Thread ni = new Thread(Run);              
            ni.Start();
            for (int i = 1; i <= 5; i++)
            {
                Console.Write("Second thread: ");
                input = int.Parse(Console.ReadLine());
                Thread.Sleep(5000);
            }
        }
    }
}
