﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader reader = new StreamReader("text.txt");
            using (reader)
            {
                string read = reader.ReadLine();
                int counter = 0;
                while (read != null)
                {
                    if (counter % 2 == 1)
                    {
                        Console.WriteLine(read);
                    }
                    counter++;
                    read = reader.ReadLine();
                }
            }
        }
    }
}
