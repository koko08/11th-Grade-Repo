﻿using System;
using System.Threading;

namespace zad2
{
    class Program
    {
        public static void RunS()
        {
            Console.WriteLine("Въведете число за сума: ");
            int n = int.Parse(Console.ReadLine());
            double sum = 0;
            for (int i = 8; i <= n; i += 4)
            {
                sum = sum + i;

            }
            Console.WriteLine(sum);
        }
        public static void RunP()
        {
            Console.WriteLine("Въведете числпо за произведение: ");
            int n = int.Parse(Console.ReadLine());
            double p = (double)(15.0 / 4.0);
            for (int i = 2; i <= n; i++)
            {
                p *= (double)(5 / i);
            }
            Console.WriteLine("{0:f2}", p);
        }
        static void Main(string[] args)
        {
            Thread threadS = new Thread(RunS);
            Thread threadP = new Thread(RunP);
            threadP.IsBackground = true;

            threadS.Start();
            if (threadS.IsAlive)
            {
                threadS.Join();
            }
            threadP.Start();
        }
    }
}
