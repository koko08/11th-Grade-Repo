﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zad1.Business;
using zad1.Model.Data;

namespace zad1.View
{
    class Display
    {
        MiniCompanyController miniCompanyController = new MiniCompanyController();
        private int closeOperationId = 0;

        private void ShowMenu()
        {
            Console.WriteLine("1. Add");
            Console.WriteLine("2. Update");
            Console.WriteLine("3. Delete");
            Console.WriteLine("4. Exit");
        }

        private void Input()
        {
            int operation = -1;
            do
            {
                ShowMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        Add();
                        break;
                    case 2:
                        Update();
                        break;
                    case 3:
                        Delete();
                        break;
                    default:
                        break;
                }
            } while (operation != closeOperationId);
        }

        public Display()
        {
            Input();
        }

        private void Add()
        {
            Department department = new Department();
            Console.Write("Enter Name: ");
            department.Name = Console.ReadLine();
            miniCompanyController.AddDepartment(department);
        }

        private void Update()
        {
            Console.Write("Enter ID to update: ");
            int id = int.Parse(Console.ReadLine());
            Department department = miniCompanyController.Get(id);
            if (department != null)
            {
                Console.Write("Name: ");
                department.Name = Console.ReadLine();
                miniCompanyController.UpdateDepartment(department);
            }
            else
            {
                Console.WriteLine("Department not found!");
            }
        }
        private void Delete()
        {
            Console.Write("Enter ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            miniCompanyController.DeleteDepartment(id);
            Console.WriteLine("Deleted!");
        }
    }
}
