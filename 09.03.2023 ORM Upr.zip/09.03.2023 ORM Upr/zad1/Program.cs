﻿using System;
using zad1.View;

namespace zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            Display display = new Display();
            
        }
    }
}
