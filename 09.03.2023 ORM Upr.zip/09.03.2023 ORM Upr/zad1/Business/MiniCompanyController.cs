﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zad1.Model;
using zad1.Model.Data;

namespace zad1.Business
{
    class MiniCompanyController
    {
        private MiniCompanyContext miniCompanyContext;
        public Department Get(int id)
        {
            using (miniCompanyContext = new MiniCompanyContext())
            {
                return miniCompanyContext.Departments.Find(id);
            }
        }
        public void AddDepartment(Department department)
        {
            using (miniCompanyContext = new MiniCompanyContext())
            {
                miniCompanyContext.Departments.Add(department);
                miniCompanyContext.SaveChanges();
            }
        }
        public void DeleteDepartment(int id)
        {
            using (miniCompanyContext = new MiniCompanyContext())
            {
                var department = miniCompanyContext.Departments.Find(id);
                if (department != null)
                {
                    miniCompanyContext.Departments.Remove(department);
                    miniCompanyContext.SaveChanges();
                }
            }
        }
        public void UpdateDepartment(Department department)
        {
            using (miniCompanyContext = new MiniCompanyContext())
            {
                var item = miniCompanyContext.Departments.Find(department.Id);
                if (item != null)
                {
                    miniCompanyContext.Entry(item).CurrentValues.SetValues(department);
                    miniCompanyContext.SaveChanges();
                }
            }
        }
    }
}
