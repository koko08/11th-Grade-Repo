﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace zad2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = Console.ReadLine().Split(", ")
                .Select(int.Parse).ToArray();
            Console.WriteLine(array.Count());
            Console.WriteLine(array.Sum());
        }
    }
}
