﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace zad1
{
    class Program
    {
        static void Main(string[] args)
        {  
            int[] array = Console.ReadLine().Split(", ")
                .Select(int.Parse).Where(n => n % 2 == 1)
                .OrderBy(n => n).ToArray();
            Console.WriteLine(String.Join(",", array));
        }
    }
}
