﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace zad4
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Напишете програма, която чете един ред на дробни числа за цени, разделени с ",". 
             Извежда цените след 5% увеличение, форматирани с 2 знака след десетичната точка.
             Да се изведат трите най-високи нови цени на нов ред.*/

            double[] array = Console.ReadLine().Split("; ").Select(double.Parse)
                .ToArray();
            array = array.Select(x => x * 1.05).OrderByDescending(x => x).Take(3).ToArray();
            foreach (var item in array)
            {
                Console.WriteLine($"{item:f2}");
            }
        }
    }
}
