﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace zad3
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] array = Console.ReadLine().Split("; ").Select(double.Parse).ToArray();
            array = array.Select(x => x * 1.2).ToArray();
            foreach (var item in array)
            {
                Console.WriteLine($"{item:f2}");
            }
        }
    }
}
