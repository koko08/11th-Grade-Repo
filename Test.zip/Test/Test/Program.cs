﻿using System;
using Test.View;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Display display = new Display();
        }
    }
}
