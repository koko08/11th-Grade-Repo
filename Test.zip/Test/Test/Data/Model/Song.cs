﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Test.Data.Model
{
    public class Song
    {
        [Key]
        public int Id { get; set; }
        public string SongName { get; set; }
        [ForeignKey(nameof(Artist))]
        public int ArtistId { get; set; }
       
        public int Bpm { get; set; }
        [ForeignKey(nameof(Genre))]
        public int GenreId { get; set; }
       
        public TimeSpan Length { get; set; }
        public DateTime ReleaseDate { get; set; }
        public string LyricsWriter { get; set; }
        public string Producer { get; set; }
        public Genre Genre { get; set; }
        //public Artist Artist { get; set; }
        public Band Band { get; set; }
    }
}
