﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Test.Data.Model
{
    public class Subgenre
    {
        [Key]
        public int Id { get; set; }
        public string SubgenreName { get; set; }
        public Genre Genre { get; set; }
    }
}
