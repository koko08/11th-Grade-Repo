﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Entities
{
    public class Genre
    {
        [Key]
        public int Id { get; set; }
        public string GenreName { get; set; }
        [ForeignKey(nameof(Subgenre))]
        public int SubgenresId { get; set; }
        public ICollection<Subgenre> Subgenres { get; set; }
        public ICollection<Song> Songs { get; set; }
    }
}
