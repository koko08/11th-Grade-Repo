﻿
namespace SongDBForm
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabArtist = new System.Windows.Forms.TabPage();
            this.btnSaveArtist = new System.Windows.Forms.Button();
            this.btnDeleteArtist = new System.Windows.Forms.Button();
            this.btnUpdateArtist = new System.Windows.Forms.Button();
            this.btnInsertArtist = new System.Windows.Forms.Button();
            this.dataGridArtist = new System.Windows.Forms.DataGridView();
            this.txtBandId = new System.Windows.Forms.TextBox();
            this.txtNickname = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblBandId = new System.Windows.Forms.Label();
            this.lblNickname = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.tabBand = new System.Windows.Forms.TabPage();
            this.txtBandName = new System.Windows.Forms.TextBox();
            this.lblBandName = new System.Windows.Forms.Label();
            this.btnSaveBand = new System.Windows.Forms.Button();
            this.btnDeleteBand = new System.Windows.Forms.Button();
            this.btnUpdateBand = new System.Windows.Forms.Button();
            this.btnInsertBand = new System.Windows.Forms.Button();
            this.dataGridBand = new System.Windows.Forms.DataGridView();
            this.tabGenre = new System.Windows.Forms.TabPage();
            this.tabSong = new System.Windows.Forms.TabPage();
            this.tabSubgenre = new System.Windows.Forms.TabPage();
            this.lblGenreName = new System.Windows.Forms.Label();
            this.lblSubgenreId = new System.Windows.Forms.Label();
            this.txtGenreName = new System.Windows.Forms.TextBox();
            this.txtSubgenreId = new System.Windows.Forms.TextBox();
            this.btnInsertGenre = new System.Windows.Forms.Button();
            this.btnUpdateGenre = new System.Windows.Forms.Button();
            this.btnDeleteGenre = new System.Windows.Forms.Button();
            this.btnSaveGenre = new System.Windows.Forms.Button();
            this.dataGridGenre = new System.Windows.Forms.DataGridView();
            this.lblSongName = new System.Windows.Forms.Label();
            this.lblArtistId = new System.Windows.Forms.Label();
            this.lblBPM = new System.Windows.Forms.Label();
            this.lblGenreId = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblLyricsWriter = new System.Windows.Forms.Label();
            this.lblProducer = new System.Windows.Forms.Label();
            this.txtSongName = new System.Windows.Forms.TextBox();
            this.txtArtistId = new System.Windows.Forms.TextBox();
            this.txtBPM = new System.Windows.Forms.TextBox();
            this.txtGenreId = new System.Windows.Forms.TextBox();
            this.txtLength = new System.Windows.Forms.TextBox();
            this.txtLyricsWriter = new System.Windows.Forms.TextBox();
            this.txtProducer = new System.Windows.Forms.TextBox();
            this.btnInsertSong = new System.Windows.Forms.Button();
            this.btnUpdateSong = new System.Windows.Forms.Button();
            this.btnDeleteSong = new System.Windows.Forms.Button();
            this.btnSaveSong = new System.Windows.Forms.Button();
            this.dataGridSong = new System.Windows.Forms.DataGridView();
            this.lblSubgenreName = new System.Windows.Forms.Label();
            this.txtSubgenreName = new System.Windows.Forms.TextBox();
            this.btnInsertSubgenre = new System.Windows.Forms.Button();
            this.btnUpdateSubgenre = new System.Windows.Forms.Button();
            this.btnDeleteSubgenre = new System.Windows.Forms.Button();
            this.btnSaveSubgenre = new System.Windows.Forms.Button();
            this.dataGridSubgenre = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabArtist.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridArtist)).BeginInit();
            this.tabBand.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridBand)).BeginInit();
            this.tabGenre.SuspendLayout();
            this.tabSong.SuspendLayout();
            this.tabSubgenre.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridGenre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSubgenre)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabArtist);
            this.tabControl1.Controls.Add(this.tabBand);
            this.tabControl1.Controls.Add(this.tabGenre);
            this.tabControl1.Controls.Add(this.tabSong);
            this.tabControl1.Controls.Add(this.tabSubgenre);
            this.tabControl1.Location = new System.Drawing.Point(-3, 0);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(805, 453);
            this.tabControl1.TabIndex = 0;
            // 
            // tabArtist
            // 
            this.tabArtist.Controls.Add(this.btnSaveArtist);
            this.tabArtist.Controls.Add(this.btnDeleteArtist);
            this.tabArtist.Controls.Add(this.btnUpdateArtist);
            this.tabArtist.Controls.Add(this.btnInsertArtist);
            this.tabArtist.Controls.Add(this.dataGridArtist);
            this.tabArtist.Controls.Add(this.txtBandId);
            this.tabArtist.Controls.Add(this.txtNickname);
            this.tabArtist.Controls.Add(this.txtLastName);
            this.tabArtist.Controls.Add(this.txtFirstName);
            this.tabArtist.Controls.Add(this.lblBandId);
            this.tabArtist.Controls.Add(this.lblNickname);
            this.tabArtist.Controls.Add(this.lblLastName);
            this.tabArtist.Controls.Add(this.lblFirstName);
            this.tabArtist.Location = new System.Drawing.Point(4, 24);
            this.tabArtist.Name = "tabArtist";
            this.tabArtist.Padding = new System.Windows.Forms.Padding(3);
            this.tabArtist.Size = new System.Drawing.Size(797, 425);
            this.tabArtist.TabIndex = 0;
            this.tabArtist.Text = "Artist";
            this.tabArtist.UseVisualStyleBackColor = true;
            // 
            // btnSaveArtist
            // 
            this.btnSaveArtist.Location = new System.Drawing.Point(114, 259);
            this.btnSaveArtist.Name = "btnSaveArtist";
            this.btnSaveArtist.Size = new System.Drawing.Size(75, 23);
            this.btnSaveArtist.TabIndex = 12;
            this.btnSaveArtist.Text = "Save";
            this.btnSaveArtist.UseVisualStyleBackColor = true;
            this.btnSaveArtist.Visible = false;
            // 
            // btnDeleteArtist
            // 
            this.btnDeleteArtist.Location = new System.Drawing.Point(205, 230);
            this.btnDeleteArtist.Name = "btnDeleteArtist";
            this.btnDeleteArtist.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteArtist.TabIndex = 11;
            this.btnDeleteArtist.Text = "Delete";
            this.btnDeleteArtist.UseVisualStyleBackColor = true;
            // 
            // btnUpdateArtist
            // 
            this.btnUpdateArtist.Location = new System.Drawing.Point(114, 230);
            this.btnUpdateArtist.Name = "btnUpdateArtist";
            this.btnUpdateArtist.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateArtist.TabIndex = 10;
            this.btnUpdateArtist.Text = "Update";
            this.btnUpdateArtist.UseVisualStyleBackColor = true;
            // 
            // btnInsertArtist
            // 
            this.btnInsertArtist.Location = new System.Drawing.Point(21, 230);
            this.btnInsertArtist.Name = "btnInsertArtist";
            this.btnInsertArtist.Size = new System.Drawing.Size(75, 23);
            this.btnInsertArtist.TabIndex = 9;
            this.btnInsertArtist.Text = "Insert";
            this.btnInsertArtist.UseVisualStyleBackColor = true;
            // 
            // dataGridArtist
            // 
            this.dataGridArtist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridArtist.Location = new System.Drawing.Point(312, 40);
            this.dataGridArtist.Name = "dataGridArtist";
            this.dataGridArtist.RowTemplate.Height = 25;
            this.dataGridArtist.Size = new System.Drawing.Size(475, 248);
            this.dataGridArtist.TabIndex = 8;
            // 
            // txtBandId
            // 
            this.txtBandId.Location = new System.Drawing.Point(92, 181);
            this.txtBandId.Name = "txtBandId";
            this.txtBandId.Size = new System.Drawing.Size(160, 23);
            this.txtBandId.TabIndex = 7;
            // 
            // txtNickname
            // 
            this.txtNickname.Location = new System.Drawing.Point(92, 135);
            this.txtNickname.Name = "txtNickname";
            this.txtNickname.Size = new System.Drawing.Size(160, 23);
            this.txtNickname.TabIndex = 6;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(92, 86);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(160, 23);
            this.txtLastName.TabIndex = 5;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(92, 40);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(160, 23);
            this.txtFirstName.TabIndex = 4;
            // 
            // lblBandId
            // 
            this.lblBandId.AutoSize = true;
            this.lblBandId.Location = new System.Drawing.Point(21, 181);
            this.lblBandId.Name = "lblBandId";
            this.lblBandId.Size = new System.Drawing.Size(47, 15);
            this.lblBandId.TabIndex = 3;
            this.lblBandId.Text = "Band Id";
            // 
            // lblNickname
            // 
            this.lblNickname.AutoSize = true;
            this.lblNickname.Location = new System.Drawing.Point(21, 135);
            this.lblNickname.Name = "lblNickname";
            this.lblNickname.Size = new System.Drawing.Size(61, 15);
            this.lblNickname.TabIndex = 2;
            this.lblNickname.Text = "Nickname";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(21, 94);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(63, 15);
            this.lblLastName.TabIndex = 1;
            this.lblLastName.Text = "Last Name";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(21, 43);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(64, 15);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "First Name";
            // 
            // tabBand
            // 
            this.tabBand.Controls.Add(this.txtBandName);
            this.tabBand.Controls.Add(this.lblBandName);
            this.tabBand.Controls.Add(this.btnSaveBand);
            this.tabBand.Controls.Add(this.btnDeleteBand);
            this.tabBand.Controls.Add(this.btnUpdateBand);
            this.tabBand.Controls.Add(this.btnInsertBand);
            this.tabBand.Controls.Add(this.dataGridBand);
            this.tabBand.Location = new System.Drawing.Point(4, 24);
            this.tabBand.Name = "tabBand";
            this.tabBand.Padding = new System.Windows.Forms.Padding(3);
            this.tabBand.Size = new System.Drawing.Size(797, 425);
            this.tabBand.TabIndex = 1;
            this.tabBand.Text = "Band";
            this.tabBand.UseVisualStyleBackColor = true;
            // 
            // txtBandName
            // 
            this.txtBandName.Location = new System.Drawing.Point(129, 73);
            this.txtBandName.Name = "txtBandName";
            this.txtBandName.Size = new System.Drawing.Size(182, 23);
            this.txtBandName.TabIndex = 6;
            // 
            // lblBandName
            // 
            this.lblBandName.AutoSize = true;
            this.lblBandName.Location = new System.Drawing.Point(25, 73);
            this.lblBandName.Name = "lblBandName";
            this.lblBandName.Size = new System.Drawing.Size(69, 15);
            this.lblBandName.TabIndex = 5;
            this.lblBandName.Text = "Band Name";
            // 
            // btnSaveBand
            // 
            this.btnSaveBand.Location = new System.Drawing.Point(129, 152);
            this.btnSaveBand.Name = "btnSaveBand";
            this.btnSaveBand.Size = new System.Drawing.Size(75, 23);
            this.btnSaveBand.TabIndex = 4;
            this.btnSaveBand.Text = "Save";
            this.btnSaveBand.UseVisualStyleBackColor = true;
            this.btnSaveBand.Visible = false;
            // 
            // btnDeleteBand
            // 
            this.btnDeleteBand.Location = new System.Drawing.Point(236, 123);
            this.btnDeleteBand.Name = "btnDeleteBand";
            this.btnDeleteBand.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteBand.TabIndex = 3;
            this.btnDeleteBand.Text = "Delete";
            this.btnDeleteBand.UseVisualStyleBackColor = true;
            // 
            // btnUpdateBand
            // 
            this.btnUpdateBand.Location = new System.Drawing.Point(129, 123);
            this.btnUpdateBand.Name = "btnUpdateBand";
            this.btnUpdateBand.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateBand.TabIndex = 2;
            this.btnUpdateBand.Text = "Update";
            this.btnUpdateBand.UseVisualStyleBackColor = true;
            // 
            // btnInsertBand
            // 
            this.btnInsertBand.Location = new System.Drawing.Point(25, 123);
            this.btnInsertBand.Name = "btnInsertBand";
            this.btnInsertBand.Size = new System.Drawing.Size(75, 23);
            this.btnInsertBand.TabIndex = 1;
            this.btnInsertBand.Text = "Insert";
            this.btnInsertBand.UseVisualStyleBackColor = true;
            // 
            // dataGridBand
            // 
            this.dataGridBand.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridBand.Location = new System.Drawing.Point(359, 55);
            this.dataGridBand.Name = "dataGridBand";
            this.dataGridBand.RowTemplate.Height = 25;
            this.dataGridBand.Size = new System.Drawing.Size(394, 187);
            this.dataGridBand.TabIndex = 0;
            // 
            // tabGenre
            // 
            this.tabGenre.Controls.Add(this.dataGridGenre);
            this.tabGenre.Controls.Add(this.btnSaveGenre);
            this.tabGenre.Controls.Add(this.btnDeleteGenre);
            this.tabGenre.Controls.Add(this.btnUpdateGenre);
            this.tabGenre.Controls.Add(this.btnInsertGenre);
            this.tabGenre.Controls.Add(this.txtSubgenreId);
            this.tabGenre.Controls.Add(this.txtGenreName);
            this.tabGenre.Controls.Add(this.lblSubgenreId);
            this.tabGenre.Controls.Add(this.lblGenreName);
            this.tabGenre.Location = new System.Drawing.Point(4, 24);
            this.tabGenre.Name = "tabGenre";
            this.tabGenre.Padding = new System.Windows.Forms.Padding(3);
            this.tabGenre.Size = new System.Drawing.Size(797, 425);
            this.tabGenre.TabIndex = 2;
            this.tabGenre.Text = "Genre";
            this.tabGenre.UseVisualStyleBackColor = true;
            // 
            // tabSong
            // 
            this.tabSong.Controls.Add(this.dataGridSong);
            this.tabSong.Controls.Add(this.btnSaveSong);
            this.tabSong.Controls.Add(this.btnDeleteSong);
            this.tabSong.Controls.Add(this.btnUpdateSong);
            this.tabSong.Controls.Add(this.btnInsertSong);
            this.tabSong.Controls.Add(this.txtProducer);
            this.tabSong.Controls.Add(this.txtLyricsWriter);
            this.tabSong.Controls.Add(this.txtLength);
            this.tabSong.Controls.Add(this.txtGenreId);
            this.tabSong.Controls.Add(this.txtBPM);
            this.tabSong.Controls.Add(this.txtArtistId);
            this.tabSong.Controls.Add(this.txtSongName);
            this.tabSong.Controls.Add(this.lblProducer);
            this.tabSong.Controls.Add(this.lblLyricsWriter);
            this.tabSong.Controls.Add(this.label5);
            this.tabSong.Controls.Add(this.lblGenreId);
            this.tabSong.Controls.Add(this.lblBPM);
            this.tabSong.Controls.Add(this.lblArtistId);
            this.tabSong.Controls.Add(this.lblSongName);
            this.tabSong.Location = new System.Drawing.Point(4, 24);
            this.tabSong.Name = "tabSong";
            this.tabSong.Padding = new System.Windows.Forms.Padding(3);
            this.tabSong.Size = new System.Drawing.Size(797, 425);
            this.tabSong.TabIndex = 3;
            this.tabSong.Text = "Song";
            this.tabSong.UseVisualStyleBackColor = true;
            // 
            // tabSubgenre
            // 
            this.tabSubgenre.Controls.Add(this.dataGridSubgenre);
            this.tabSubgenre.Controls.Add(this.btnSaveSubgenre);
            this.tabSubgenre.Controls.Add(this.btnDeleteSubgenre);
            this.tabSubgenre.Controls.Add(this.btnUpdateSubgenre);
            this.tabSubgenre.Controls.Add(this.btnInsertSubgenre);
            this.tabSubgenre.Controls.Add(this.txtSubgenreName);
            this.tabSubgenre.Controls.Add(this.lblSubgenreName);
            this.tabSubgenre.Location = new System.Drawing.Point(4, 24);
            this.tabSubgenre.Name = "tabSubgenre";
            this.tabSubgenre.Padding = new System.Windows.Forms.Padding(3);
            this.tabSubgenre.Size = new System.Drawing.Size(797, 425);
            this.tabSubgenre.TabIndex = 4;
            this.tabSubgenre.Text = "Subgenre";
            this.tabSubgenre.UseVisualStyleBackColor = true;
            // 
            // lblGenreName
            // 
            this.lblGenreName.AutoSize = true;
            this.lblGenreName.Location = new System.Drawing.Point(23, 58);
            this.lblGenreName.Name = "lblGenreName";
            this.lblGenreName.Size = new System.Drawing.Size(73, 15);
            this.lblGenreName.TabIndex = 0;
            this.lblGenreName.Text = "Genre Name";
            // 
            // lblSubgenreId
            // 
            this.lblSubgenreId.AutoSize = true;
            this.lblSubgenreId.Location = new System.Drawing.Point(23, 113);
            this.lblSubgenreId.Name = "lblSubgenreId";
            this.lblSubgenreId.Size = new System.Drawing.Size(70, 15);
            this.lblSubgenreId.TabIndex = 1;
            this.lblSubgenreId.Text = "Subgenre Id";
            // 
            // txtGenreName
            // 
            this.txtGenreName.Location = new System.Drawing.Point(121, 55);
            this.txtGenreName.Name = "txtGenreName";
            this.txtGenreName.Size = new System.Drawing.Size(175, 23);
            this.txtGenreName.TabIndex = 2;
            // 
            // txtSubgenreId
            // 
            this.txtSubgenreId.Location = new System.Drawing.Point(121, 110);
            this.txtSubgenreId.Name = "txtSubgenreId";
            this.txtSubgenreId.Size = new System.Drawing.Size(175, 23);
            this.txtSubgenreId.TabIndex = 3;
            // 
            // btnInsertGenre
            // 
            this.btnInsertGenre.Location = new System.Drawing.Point(23, 162);
            this.btnInsertGenre.Name = "btnInsertGenre";
            this.btnInsertGenre.Size = new System.Drawing.Size(75, 23);
            this.btnInsertGenre.TabIndex = 4;
            this.btnInsertGenre.Text = "Insert";
            this.btnInsertGenre.UseVisualStyleBackColor = true;
            // 
            // btnUpdateGenre
            // 
            this.btnUpdateGenre.Location = new System.Drawing.Point(121, 162);
            this.btnUpdateGenre.Name = "btnUpdateGenre";
            this.btnUpdateGenre.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateGenre.TabIndex = 5;
            this.btnUpdateGenre.Text = "Update";
            this.btnUpdateGenre.UseVisualStyleBackColor = true;
            // 
            // btnDeleteGenre
            // 
            this.btnDeleteGenre.Location = new System.Drawing.Point(221, 162);
            this.btnDeleteGenre.Name = "btnDeleteGenre";
            this.btnDeleteGenre.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteGenre.TabIndex = 6;
            this.btnDeleteGenre.Text = "Delete";
            this.btnDeleteGenre.UseVisualStyleBackColor = true;
            // 
            // btnSaveGenre
            // 
            this.btnSaveGenre.Location = new System.Drawing.Point(121, 191);
            this.btnSaveGenre.Name = "btnSaveGenre";
            this.btnSaveGenre.Size = new System.Drawing.Size(75, 23);
            this.btnSaveGenre.TabIndex = 7;
            this.btnSaveGenre.Text = "Save";
            this.btnSaveGenre.UseVisualStyleBackColor = true;
            this.btnSaveGenre.Visible = false;
            // 
            // dataGridGenre
            // 
            this.dataGridGenre.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridGenre.Location = new System.Drawing.Point(323, 35);
            this.dataGridGenre.Name = "dataGridGenre";
            this.dataGridGenre.RowTemplate.Height = 25;
            this.dataGridGenre.Size = new System.Drawing.Size(464, 235);
            this.dataGridGenre.TabIndex = 8;
            // 
            // lblSongName
            // 
            this.lblSongName.AutoSize = true;
            this.lblSongName.Location = new System.Drawing.Point(33, 32);
            this.lblSongName.Name = "lblSongName";
            this.lblSongName.Size = new System.Drawing.Size(69, 15);
            this.lblSongName.TabIndex = 0;
            this.lblSongName.Text = "Song Name";
            // 
            // lblArtistId
            // 
            this.lblArtistId.AutoSize = true;
            this.lblArtistId.Location = new System.Drawing.Point(33, 62);
            this.lblArtistId.Name = "lblArtistId";
            this.lblArtistId.Size = new System.Drawing.Size(48, 15);
            this.lblArtistId.TabIndex = 1;
            this.lblArtistId.Text = "Artist Id";
            // 
            // lblBPM
            // 
            this.lblBPM.AutoSize = true;
            this.lblBPM.Location = new System.Drawing.Point(33, 92);
            this.lblBPM.Name = "lblBPM";
            this.lblBPM.Size = new System.Drawing.Size(32, 15);
            this.lblBPM.TabIndex = 2;
            this.lblBPM.Text = "BPM";
            // 
            // lblGenreId
            // 
            this.lblGenreId.AutoSize = true;
            this.lblGenreId.Location = new System.Drawing.Point(33, 122);
            this.lblGenreId.Name = "lblGenreId";
            this.lblGenreId.Size = new System.Drawing.Size(51, 15);
            this.lblGenreId.TabIndex = 3;
            this.lblGenreId.Text = "Genre Id";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Length";
            // 
            // lblLyricsWriter
            // 
            this.lblLyricsWriter.AutoSize = true;
            this.lblLyricsWriter.Location = new System.Drawing.Point(33, 180);
            this.lblLyricsWriter.Name = "lblLyricsWriter";
            this.lblLyricsWriter.Size = new System.Drawing.Size(72, 15);
            this.lblLyricsWriter.TabIndex = 5;
            this.lblLyricsWriter.Text = "Lyrics Writer";
            // 
            // lblProducer
            // 
            this.lblProducer.AutoSize = true;
            this.lblProducer.Location = new System.Drawing.Point(33, 210);
            this.lblProducer.Name = "lblProducer";
            this.lblProducer.Size = new System.Drawing.Size(55, 15);
            this.lblProducer.TabIndex = 6;
            this.lblProducer.Text = "Producer";
            // 
            // txtSongName
            // 
            this.txtSongName.Location = new System.Drawing.Point(128, 32);
            this.txtSongName.Name = "txtSongName";
            this.txtSongName.Size = new System.Drawing.Size(175, 23);
            this.txtSongName.TabIndex = 7;
            // 
            // txtArtistId
            // 
            this.txtArtistId.Location = new System.Drawing.Point(128, 62);
            this.txtArtistId.Name = "txtArtistId";
            this.txtArtistId.Size = new System.Drawing.Size(175, 23);
            this.txtArtistId.TabIndex = 8;
            // 
            // txtBPM
            // 
            this.txtBPM.Location = new System.Drawing.Point(128, 92);
            this.txtBPM.Name = "txtBPM";
            this.txtBPM.Size = new System.Drawing.Size(175, 23);
            this.txtBPM.TabIndex = 9;
            // 
            // txtGenreId
            // 
            this.txtGenreId.Location = new System.Drawing.Point(128, 122);
            this.txtGenreId.Name = "txtGenreId";
            this.txtGenreId.Size = new System.Drawing.Size(175, 23);
            this.txtGenreId.TabIndex = 10;
            // 
            // txtLength
            // 
            this.txtLength.Location = new System.Drawing.Point(128, 151);
            this.txtLength.Name = "txtLength";
            this.txtLength.Size = new System.Drawing.Size(175, 23);
            this.txtLength.TabIndex = 11;
            // 
            // txtLyricsWriter
            // 
            this.txtLyricsWriter.Location = new System.Drawing.Point(128, 180);
            this.txtLyricsWriter.Name = "txtLyricsWriter";
            this.txtLyricsWriter.Size = new System.Drawing.Size(175, 23);
            this.txtLyricsWriter.TabIndex = 12;
            // 
            // txtProducer
            // 
            this.txtProducer.Location = new System.Drawing.Point(128, 210);
            this.txtProducer.Name = "txtProducer";
            this.txtProducer.Size = new System.Drawing.Size(175, 23);
            this.txtProducer.TabIndex = 13;
            // 
            // btnInsertSong
            // 
            this.btnInsertSong.Location = new System.Drawing.Point(33, 257);
            this.btnInsertSong.Name = "btnInsertSong";
            this.btnInsertSong.Size = new System.Drawing.Size(75, 23);
            this.btnInsertSong.TabIndex = 14;
            this.btnInsertSong.Text = "Insert";
            this.btnInsertSong.UseVisualStyleBackColor = true;
            // 
            // btnUpdateSong
            // 
            this.btnUpdateSong.Location = new System.Drawing.Point(128, 256);
            this.btnUpdateSong.Name = "btnUpdateSong";
            this.btnUpdateSong.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateSong.TabIndex = 15;
            this.btnUpdateSong.Text = "Update";
            this.btnUpdateSong.UseVisualStyleBackColor = true;
            // 
            // btnDeleteSong
            // 
            this.btnDeleteSong.Location = new System.Drawing.Point(228, 257);
            this.btnDeleteSong.Name = "btnDeleteSong";
            this.btnDeleteSong.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteSong.TabIndex = 16;
            this.btnDeleteSong.Text = "Delete";
            this.btnDeleteSong.UseVisualStyleBackColor = true;
            // 
            // btnSaveSong
            // 
            this.btnSaveSong.Location = new System.Drawing.Point(128, 285);
            this.btnSaveSong.Name = "btnSaveSong";
            this.btnSaveSong.Size = new System.Drawing.Size(75, 23);
            this.btnSaveSong.TabIndex = 17;
            this.btnSaveSong.Text = "Save";
            this.btnSaveSong.UseVisualStyleBackColor = true;
            this.btnSaveSong.Visible = false;
            // 
            // dataGridSong
            // 
            this.dataGridSong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridSong.Location = new System.Drawing.Point(326, 32);
            this.dataGridSong.Name = "dataGridSong";
            this.dataGridSong.RowTemplate.Height = 25;
            this.dataGridSong.Size = new System.Drawing.Size(461, 276);
            this.dataGridSong.TabIndex = 18;
            // 
            // lblSubgenreName
            // 
            this.lblSubgenreName.AutoSize = true;
            this.lblSubgenreName.Location = new System.Drawing.Point(22, 107);
            this.lblSubgenreName.Name = "lblSubgenreName";
            this.lblSubgenreName.Size = new System.Drawing.Size(92, 15);
            this.lblSubgenreName.TabIndex = 0;
            this.lblSubgenreName.Text = "Subgenre Name";
            // 
            // txtSubgenreName
            // 
            this.txtSubgenreName.Location = new System.Drawing.Point(120, 104);
            this.txtSubgenreName.Name = "txtSubgenreName";
            this.txtSubgenreName.Size = new System.Drawing.Size(175, 23);
            this.txtSubgenreName.TabIndex = 1;
            // 
            // btnInsertSubgenre
            // 
            this.btnInsertSubgenre.Location = new System.Drawing.Point(22, 193);
            this.btnInsertSubgenre.Name = "btnInsertSubgenre";
            this.btnInsertSubgenre.Size = new System.Drawing.Size(75, 23);
            this.btnInsertSubgenre.TabIndex = 2;
            this.btnInsertSubgenre.Text = "Insert";
            this.btnInsertSubgenre.UseVisualStyleBackColor = true;
            // 
            // btnUpdateSubgenre
            // 
            this.btnUpdateSubgenre.Location = new System.Drawing.Point(120, 193);
            this.btnUpdateSubgenre.Name = "btnUpdateSubgenre";
            this.btnUpdateSubgenre.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateSubgenre.TabIndex = 3;
            this.btnUpdateSubgenre.Text = "Update";
            this.btnUpdateSubgenre.UseVisualStyleBackColor = true;
            // 
            // btnDeleteSubgenre
            // 
            this.btnDeleteSubgenre.Location = new System.Drawing.Point(220, 193);
            this.btnDeleteSubgenre.Name = "btnDeleteSubgenre";
            this.btnDeleteSubgenre.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteSubgenre.TabIndex = 4;
            this.btnDeleteSubgenre.Text = "Delete";
            this.btnDeleteSubgenre.UseVisualStyleBackColor = true;
            // 
            // btnSaveSubgenre
            // 
            this.btnSaveSubgenre.Location = new System.Drawing.Point(120, 222);
            this.btnSaveSubgenre.Name = "btnSaveSubgenre";
            this.btnSaveSubgenre.Size = new System.Drawing.Size(75, 23);
            this.btnSaveSubgenre.TabIndex = 5;
            this.btnSaveSubgenre.Text = "Save";
            this.btnSaveSubgenre.UseVisualStyleBackColor = true;
            this.btnSaveSubgenre.Visible = false;
            // 
            // dataGridSubgenre
            // 
            this.dataGridSubgenre.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridSubgenre.Location = new System.Drawing.Point(324, 85);
            this.dataGridSubgenre.Name = "dataGridSubgenre";
            this.dataGridSubgenre.RowTemplate.Height = 25;
            this.dataGridSubgenre.Size = new System.Drawing.Size(451, 195);
            this.dataGridSubgenre.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabArtist.ResumeLayout(false);
            this.tabArtist.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridArtist)).EndInit();
            this.tabBand.ResumeLayout(false);
            this.tabBand.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridBand)).EndInit();
            this.tabGenre.ResumeLayout(false);
            this.tabGenre.PerformLayout();
            this.tabSong.ResumeLayout(false);
            this.tabSong.PerformLayout();
            this.tabSubgenre.ResumeLayout(false);
            this.tabSubgenre.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridGenre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSubgenre)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabArtist;
        private System.Windows.Forms.TabPage tabBand;
        private System.Windows.Forms.TabPage tabGenre;
        private System.Windows.Forms.TabPage tabSong;
        private System.Windows.Forms.TabPage tabSubgenre;
        private System.Windows.Forms.TextBox txtBandId;
        private System.Windows.Forms.TextBox txtNickname;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblBandId;
        private System.Windows.Forms.Label lblNickname;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Button btnSaveArtist;
        private System.Windows.Forms.Button btnDeleteArtist;
        private System.Windows.Forms.Button btnUpdateArtist;
        private System.Windows.Forms.Button btnInsertArtist;
        private System.Windows.Forms.DataGridView dataGridArtist;
        private System.Windows.Forms.TextBox txtBandName;
        private System.Windows.Forms.Label lblBandName;
        private System.Windows.Forms.Button btnSaveBand;
        private System.Windows.Forms.Button btnDeleteBand;
        private System.Windows.Forms.Button btnUpdateBand;
        private System.Windows.Forms.Button btnInsertBand;
        private System.Windows.Forms.DataGridView dataGridBand;
        private System.Windows.Forms.TextBox txtSubgenreId;
        private System.Windows.Forms.TextBox txtGenreName;
        private System.Windows.Forms.Label lblSubgenreId;
        private System.Windows.Forms.Label lblGenreName;
        private System.Windows.Forms.DataGridView dataGridGenre;
        private System.Windows.Forms.Button btnSaveGenre;
        private System.Windows.Forms.Button btnDeleteGenre;
        private System.Windows.Forms.Button btnUpdateGenre;
        private System.Windows.Forms.Button btnInsertGenre;
        private System.Windows.Forms.Label lblProducer;
        private System.Windows.Forms.Label lblLyricsWriter;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblGenreId;
        private System.Windows.Forms.Label lblBPM;
        private System.Windows.Forms.Label lblArtistId;
        private System.Windows.Forms.Label lblSongName;
        private System.Windows.Forms.DataGridView dataGridSong;
        private System.Windows.Forms.Button btnSaveSong;
        private System.Windows.Forms.Button btnDeleteSong;
        private System.Windows.Forms.Button btnUpdateSong;
        private System.Windows.Forms.Button btnInsertSong;
        private System.Windows.Forms.TextBox txtProducer;
        private System.Windows.Forms.TextBox txtLyricsWriter;
        private System.Windows.Forms.TextBox txtLength;
        private System.Windows.Forms.TextBox txtGenreId;
        private System.Windows.Forms.TextBox txtBPM;
        private System.Windows.Forms.TextBox txtArtistId;
        private System.Windows.Forms.TextBox txtSongName;
        private System.Windows.Forms.Button btnSaveSubgenre;
        private System.Windows.Forms.Button btnDeleteSubgenre;
        private System.Windows.Forms.Button btnUpdateSubgenre;
        private System.Windows.Forms.Button btnInsertSubgenre;
        private System.Windows.Forms.TextBox txtSubgenreName;
        private System.Windows.Forms.Label lblSubgenreName;
        private System.Windows.Forms.DataGridView dataGridSubgenre;
    }
}

