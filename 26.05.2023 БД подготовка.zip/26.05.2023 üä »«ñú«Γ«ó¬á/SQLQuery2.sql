﻿alter view FunnyStatisticGames
as
select g.name, start_date, strength, defence, mind, speed, luck
from games as g
join game_types as gt
on g.game_type_id = gt.id
join statisticals as s
on gt.bonus_stats_id = s.id
where gt.name = 'Funny'