﻿select * from FunnyStatisticGames
where datediff(YEAR, start_date, current_timestamp) < 10
order by FunnyStatisticGames.name