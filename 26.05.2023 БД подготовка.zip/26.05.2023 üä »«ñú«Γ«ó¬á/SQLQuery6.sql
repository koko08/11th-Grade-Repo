﻿create function fnNeedToUpgrate(@speed int)
returns varchar(3)
as
begin
declare @ReturnValue varchar(3)
set @ReturnValue = iif(@speed < 10, 'Yes', 'No')
return @ReturnValue
end
go

select *, dbo.fnNeedToUpgrate(speed) as NeedUpgrade
from FunnyStatisticGames