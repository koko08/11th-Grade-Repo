﻿using System;
using System.Threading;

namespace zad1
{
    class Program
    {
        public static void Factoriel1()
        {
            int n = int.Parse(Console.ReadLine());
            int result = 1;
            for (int i = 1; i <= n; i++)
            {
                result = result * i;            
                Console.WriteLine(result);

            }
        }
        public static void Factoriel2()
        {
            int n = int.Parse(Console.ReadLine());
            int result = 1;
            for (int i = n; i > 1; i -= 2)
            {
                result = result * i;
                Console.WriteLine(result);
            }

        }
        static void Main(string[] args)
        {
            Thread thread = new Thread(Factoriel2);
            thread.Start();
        }
    }
}
