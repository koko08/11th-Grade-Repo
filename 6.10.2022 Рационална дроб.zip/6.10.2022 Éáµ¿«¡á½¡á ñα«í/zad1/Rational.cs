﻿using System;
using System.Collections.Generic;
using System.Text;

namespace zad1
{
    class Rational
    {
        private int num; //Числител
        private int denum; //Знаменател
        private double dec; //Десетично представяне
        public int Num
        {
            set { this.num = value; }
            get { return this.num; }
        }
        public int Denum
        {
            set { this.denum = value; }
            get { return this.denum; }
        }
        public double Dec
        {
            set { this.dec = value; }
            get { return this.dec; }
        }
        public Rational(int n, int d)//Конструктор образуващ една дроб
        {
            this.num = n;
            this.denum = d;
        }
        public Rational(int n)//Конструктор превръщащ число в рационална дроб
        {
            this.num = n;
            this.denum = 1;
        }
        public Rational(Rational r)//Копиращ контруктор
        {
            this.num = r.num;
            this.denum = r.denum;
        }
        public void Add(Rational r)
        {
            this.num = this.num * r.denum + this.denum * r.num;
            this.denum = this.denum * r.denum;
        }
        public void Subtract(Rational r)
        {
            this.num = this.num * r.denum - this.denum * r.num;
            this.denum = this.denum * r.denum;
        }
        public void Multiply(Rational r)
        {
            this.num = this.num * r.num;
            this.denum = this.denum * r.denum;
        }
        public void Divide(Rational r)
        {
            this.num = this.num * r.denum;
            this.denum = this.denum * r.num;
        }
        public int Compare(Rational r)
        {
            if (this.num * r.denum < this.denum * r.num)
                return -1;
            if (this.num * r.denum > this.denum * r.num)
                return 1;
            return 0;
        }
        public void Print()
        {
            Console.WriteLine("{0}/{1}", Num, Denum);
        }
        public double Dei()
        {
            this.Dec = (double)this.num / this.denum;
            return this.Dec;
        }
    }
}
