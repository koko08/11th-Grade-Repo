﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace zad1.Data.Entities
{
    public class Department
    {
        [Key]
        public int Id { set; get; }
        [Required]
        public string Name { set; get; }
        public ICollection<Employee> Employees { get; }
    }
}
