﻿using System;
using System.Collections.Generic;
using System.Text;
using zad1.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace zad1.Data
{
    public class MiniCompanyContext : DbContext
    {
        public MiniCompanyContext()
        {
            Database.EnsureCreated();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var connString = "Server = (localdb)\\MSSQLLocalDB;Initial Catalog = MiniCompany;Integrated Security = true";
            optionsBuilder.UseSqlServer(connString);
        }
        public DbSet<Department> Departments { get; }
        public DbSet<Employee> Employees { get; }
        public DbSet<Project> Projects { get; }
        public DbSet<EmployeeProject> EmployeeProjects { get; }
    }
}
