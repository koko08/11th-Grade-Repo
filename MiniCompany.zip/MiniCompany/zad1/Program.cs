﻿using System;
using System.Linq;
using zad1.Data;
using zad1.Data.Entities;

namespace zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            MiniCompanyContext context = new MiniCompanyContext();
            context.Departments.Add(new Department
            {
                Id = 1,
                Name = "Logo Design",
                Employees = context.Employees.First().Id //wrong
                //object references needed
            });
            context.Employees.Add(new Employee
            {
                FirstName = "Gosho",
                LastName = "Inserted",
                DepartmentId = context.Departments.First().Id,
                IsEmployeed = true
            });

            var employee = context.Employees.Last();
            employee.FirstName = "Modified";

            context.SaveChanges();
        }
    }
}
