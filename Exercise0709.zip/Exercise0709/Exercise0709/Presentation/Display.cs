﻿using System;
using System.Collections.Generic;
using System.Text;
using Exercise0709.Data;
using Exercise0709.Data.Models;
using Exercise0709.Business;

namespace Exercise0709.Presentation
{
    class Display
    {
        private int closedOperationID = 6;
        ProductBusiness productBusiness = new ProductBusiness();
        private void ShowMenu()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 18) + "MENU" + new string(' ', 18));
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all entries");
            Console.WriteLine("2. Add new entry");
            Console.WriteLine("3. Update entry");
            Console.WriteLine("4. Fetch entry by ID");
            Console.WriteLine("5. Delete entry by ID");
            Console.WriteLine("6. Exit");
        }
        
        private void Input()
        {            
            int operation;
            do
            {
                ShowMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {                  
                }
            } while (operation != closedOperationID);
        }
        private void Add()
        {
            Product product = new Product();
            Console.Write("Enter name: ");
            product.Name = Console.ReadLine();
            Console.Write("Enter price: ");
            product.Price = decimal.Parse(Console.ReadLine());
            Console.Write("Enter stock: ");
            product.Stock = int.Parse(Console.ReadLine());
            productBusiness.Add(product);
        }
        private void ListAll()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "PRODUCTS" + new string(' ', 16));
            Console.WriteLine(new string('-', 40));
            var products = productBusiness.GetAll();
            foreach (var item in products)
            {
                Console.WriteLine("{0} {1} {2} {3}", item.Id, item.Name, item.Price, item.Stock);
            }
        }
        private void Update()
        {
            Console.Write("Enter Id to update: ");
            int id = int.Parse(Console.ReadLine());
            Product product = productBusiness.Get(id);
            if (product != null)
            {
                Console.Write("Enter name: ");
                product.Name = Console.ReadLine();
                Console.Write("Enter price: ");
                product.Price = decimal.Parse(Console.ReadLine());
                Console.Write("Enter stock: ");
                product.Stock = int.Parse(Console.ReadLine());
                productBusiness.Update(product);
            }
            else
            {
                Console.WriteLine("Product not found!");
            }
        }
    }
}
