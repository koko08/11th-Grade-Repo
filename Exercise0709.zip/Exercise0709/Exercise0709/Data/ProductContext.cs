﻿using Exercise0709.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise0709.Data
{
    public class ProductContext : DbContext
    {
        public ProductContext()
        {
            Database.EnsureCreated();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var connString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Products;Integrated Security=true;";
            optionsBuilder.UseSqlServer(connString);
        }
        public DbSet<Product> Products { get; set; }
    }
}
