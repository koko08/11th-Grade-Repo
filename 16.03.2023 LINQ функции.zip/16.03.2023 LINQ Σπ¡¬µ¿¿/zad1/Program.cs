﻿using System;
using System.Linq;

namespace zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] separators = new char[] { '.' , ',' , ':' , ';' , '(' , ')' , '[' , ']' , '\\' , '\"' , '\'' , '/' , '!' , ' ' };
            string sentence = Console.ReadLine().ToLower();
            string[] words = sentence.Split(separators);
            var result = words.Where(w => w.Length<5).OrderBy(w => w).Distinct();
            Console.WriteLine(String.Join(", ", result));
        }
    }
}
