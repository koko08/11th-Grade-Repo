﻿using System;
using System.Collections.Generic;
using System.Text;

namespace zad1
{
    class Student
    {
        private int num;
        private string nameStudent;
        private string lastName;
        private string spezialnost;
        private double srUspeh;
        public int Num
        {
            set { this.num = value; }
            get { return this.num; }
        }
        public string NameStudent
        {
            set { this.nameStudent = value; }
            get { return this.nameStudent; }
        }
        public string LastName
        {
            set { this.lastName = value; }
            get { return this.lastName; }
        }
        public string Spezialnost
        {
            set { this.spezialnost = value; }
            get { return this.spezialnost; }
        }
        public double SrUspeh
        {
            set { this.srUspeh = value; }
            get { return this.srUspeh; }
        }
        public Student(int num, string nameStudent, string lastName, string spezialnost, double srUspeh)
        {
            this.Num = num;
            this.NameStudent = nameStudent;
            this.LastName = lastName;
            this.Spezialnost = spezialnost;
            this.SrUspeh = srUspeh;
        }
        public Student() : this(0, null, null, null, 0)
        { }
        public void Print()
        {
            Console.WriteLine("Номер в клас: {0} / Име: {1} / Фамилия: {2} / Специалност: {3} / Среден успех: {4:f2}", 
                num, nameStudent, lastName, spezialnost, srUspeh);
        }
    }
}
