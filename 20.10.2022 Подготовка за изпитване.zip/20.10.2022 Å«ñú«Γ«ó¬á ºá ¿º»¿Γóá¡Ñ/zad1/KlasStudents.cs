﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace zad1
{
    class KlasStudents
    {
        private List<Student> myClass;
        public List<Student> MyClass
        {
            set { myClass = value; }
            get { return myClass; }
        }
        public KlasStudents()
        {
            MyClass = new List<Student>();
        }
    }
}
