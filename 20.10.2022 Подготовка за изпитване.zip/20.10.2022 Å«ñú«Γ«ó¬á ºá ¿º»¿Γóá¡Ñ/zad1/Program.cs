﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            KlasStudents klas = new KlasStudents();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] enter = Console.ReadLine().Split(' ');
                int num = int.Parse(enter[0]);
                string firstName = enter[1];
                string lastName = enter[2];
                string spezialnost = enter[3];
                double srUspeh = double.Parse(enter[4]);
                Student student = new Student(num, firstName, lastName, spezialnost, srUspeh);
                klas.MyClass.Add(student);
            }
            foreach (var item in klas.MyClass.OrderBy(a=>a.Spezialnost))
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}
