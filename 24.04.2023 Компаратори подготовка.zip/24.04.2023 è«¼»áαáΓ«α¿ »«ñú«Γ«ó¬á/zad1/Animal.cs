﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace zad1
{
    public class Animal : IComparable<Animal>
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public List<string> Children { get; set; }
        public Animal(string name, int age, params string[] children)
        {
            Name = name;
            Age = age;
            Children = new List<string>(children);
        }
        public override string ToString()
        {
            return $"{Name} - {Age}";
        }

        public int CompareTo(Animal other)
        {
            var compare = other.Age.CompareTo(this.Age);
            if (compare == 0)
            {
                compare = this.Name.CompareTo(other.Name);
            }
            return compare;
        }
    }
}
