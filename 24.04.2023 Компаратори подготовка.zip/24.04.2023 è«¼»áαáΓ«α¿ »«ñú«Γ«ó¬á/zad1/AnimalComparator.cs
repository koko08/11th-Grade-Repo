﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace zad1
{
    class AnimalComparator : IComparer<Animal>
    {
        public int Compare(Animal x, Animal y)
        {
            var compare = x.Name.CompareTo(y.Name);
            if (compare == 0)
            {
                compare = y.Age.CompareTo(x.Age);
            }
            return compare;
        }
    }
}
