﻿using System;
using System.Collections.Generic;

namespace zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal animalOne = new Animal("Charly", 5, "Maks");
            Animal animalTwo = new Animal("Leon", 4, "Surga", "Manu");
            Animal animalThree = new Animal("Oto", 9);
            Animal animalFoor = new Animal("Kara", 4, "Maksim");
            Animal animalFive = new Animal("Kara", 5, "Scharo", "Sara");

            ZooPark zooparkOne = new ZooPark();
            ZooPark zooparkTwo = new ZooPark(animalOne, animalTwo, animalThree, animalFoor, animalFive);
            
            zooparkTwo.Sort();

            foreach (var anim in zooparkTwo)
            {
                Console.WriteLine(anim.ToString());
            }
             
            List<Animal> zooparkThree = new List<Animal> { animalOne, animalTwo, animalThree, animalFoor, animalFive };
            AnimalComparator comparator = new AnimalComparator();
            zooparkThree.Sort(comparator);
            Console.WriteLine();

            foreach (var anim in zooparkThree)
            {
                Console.WriteLine(anim.ToString());
            }
        }
    }
}
