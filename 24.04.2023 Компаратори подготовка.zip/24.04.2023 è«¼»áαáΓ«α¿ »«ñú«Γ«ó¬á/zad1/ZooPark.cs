﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace zad1
{
    class ZooPark : IEnumerable<Animal>
    {
        private List<Animal> animals;
        public ZooPark(params Animal[] animal)
        {
            animals = new List<Animal>(animal);
        }
        public IEnumerator<Animal> GetEnumerator()
        {
            //Нуждае се от итератор (ZooParkIterator)
            return new ZooParkIterator(animals);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public void Sort()
        {
            animals.Sort();
        }
    }
}
