﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace zad1
{
    public class ZooParkIterator : IEnumerator<Animal>
    {
        public List<Animal> animals;
        public int index;
        public ZooParkIterator(List<Animal> animalList)
        {
            this.animals = animalList;
            Reset();
        }
        public Animal Current => animals[index];

        object IEnumerator.Current => Current;

        public void Dispose()
        {
            
        }

        public bool MoveNext()
        {
            index++;
            return index < animals.Count;
        }
        public void Reset()
        {
            index = -1;
        }

    }
}
